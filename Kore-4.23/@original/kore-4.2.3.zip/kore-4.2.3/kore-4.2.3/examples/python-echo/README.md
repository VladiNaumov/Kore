Example of using the asynchronous python api to create a simple
echo server.

Kore must have been built with PYTHON=1.

On the command-line run the following

$ kore echo.py

Then connect to 127.0.0.1 port 6969 using netcat or so and you'll
see it echo back everything you send it.
