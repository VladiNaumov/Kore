Kore NOHTTP example

Run:
```
	$ kodev run
```

Test:
```
	Connect to the server using openssl s_client, you will notice
	that anything sent is submitted back to your client.

	$ openssl s_client -connect 127.0.0.1:8888
```
