Kore asynchronous libcurl integration example.

This example demonstrates how you can use the asynchronous libcurl
api from Kore to perform HTTP client requests, or FTP requests, or send
emails all in an asynchronous fashion.

Run:
```
	$ kodev run
	$ curl https://127.0.0.1:8888
	$ curl https://127.0.0.1:8888/ftp
```
